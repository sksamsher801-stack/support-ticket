# SupportDesk: Django Form + JSONL file (no database) + jQuery AJAX + Cookie + Middleware

A support ticket intake page for trainees. It uses a **Django form** and a **JSONL file**
instead of models and a database. Only function-based views are used (no CBV).
No ORM, DRF, sessions or authentication.

## Run
```bash
pip install django
python manage.py runserver
```
Open http://127.0.0.1:8000/. No `migrate` is needed.

Tests: `python manage.py test supportdesk`

## How it works

| Step | What happens | Where |
|---|---|---|
| Open page | `GET /` shows the form; category is pre-selected from the cookie | `views.ticket_create` |
| Priority hint | while the user changes severity / types the description, jQuery sends an AJAX **POST** to `/api/priority/` and shows `P1`..`P4` | `static/supportdesk/ticket.js`, `views.priority_check` |
| Submit (invalid) | the **same bound form** is shown again with all input kept and an error under each field | `SupportTicketForm(request.POST, request.FILES)` |
| Submit (valid) | screenshot saved in `media/ticket_screenshots/`, ticket appended as ONE line to `data/tickets.jsonl`, cookie `last_ticket_category` set, redirect to `ticket_success` | `views.ticket_create`, `jsonl_store.append` |
| Success page | `GET /tickets/success/<uuid>/` reads the ticket back from the file | `views.ticket_success` |
| Every request | `request.audit_id` is added; shown in the footer and in the `X-Audit-ID` response header | `middleware.AuditIdMiddleware` |

## URL names

| Name | Path | Method |
|---|---|---|
| `ticket_form` | `/` | GET, POST |
| `ticket_success` | `/tickets/success/<uuid>/` | GET |
| `priority_check` | `/api/priority/` | POST only |

Templates use `{% url 'ticket_form' %}` and the view uses `redirect('ticket_success', ticket_id=...)`.

## The 5 problems and the fix

| Problem | Fix |
|---|---|
| Form loses input after an error | the form is bound to `request.POST`; the invalid form is rendered again (a file input can't be pre-filled by any browser, so the page asks to choose the screenshot again) |
| Screenshot accepted without checks | extension, content type, size (max 2 MB) **and** the first bytes of the file are checked |
| AJAX priority checker uses GET | now `@require_POST`; jQuery sends the `X-CSRFToken` header; `@csrf_exempt` is NOT used |
| No request id | `AuditIdMiddleware` |
| Remember last category | cookie `last_ticket_category` (not sessions) |

## Validation (`supportdesk/forms.py`)

| Field | Rule |
|---|---|
| trainee_name | at least 2 characters; letters, spaces and `. ' -` only (regex) |
| email | valid email (`EmailField`) |
| category | `bug`, `access`, `environment`, `content`, `other` |
| severity | `low`, `medium`, `high`, `critical` |
| description | 20 to 1000 characters |
| screenshot | optional; `.png`, `.jpg`, `.jpeg` or `.gif`; image content type; max 2 MB; real image bytes |

## Priority rule (AJAX)
Score from severity (low 1 ... critical 4). `+1` if the description has a serious word
(`production`, `down`, `crash`, `data loss`, ...), `-1` if it has a minor word (`typo`, `cosmetic`, ...).
Result: 4 = `P1 Urgent`, 3 = `P2 High`, 2 = `P3 Normal`, 1 = `P4 Low`.

Response: `{"ok": true, "priority": "P1", "label": "Urgent", "reasons": [...], "audit_id": "..."}`

## Cookie
- Name `last_ticket_category`, set only after a **successful** submit, lasts 30 days.
- On `GET /` the value is used only if it is one of the allowed categories (a cookie can be edited by the user).

## Middleware
`supportdesk/middleware.py` (`AuditIdMiddleware`) creates a new 12-character id for every request.
It prints it and sends it back in the `X-Audit-ID` header:
```
Request : 3fa9c1d2b7e4 POST /
Response: 3fa9c1d2b7e4 302
```

## Assumptions
- Screenshots are saved with a random name, never the user's file name.
- Tickets are written to `data/tickets.jsonl` (a lock allows one writer at a time; fine for the dev server).
- `DEBUG = True` and the secret key are for development only.

## Test cases

| Case | Expected |
|---|---|
| Valid ticket, no screenshot | 302 to success page, one new line in `tickets.jsonl`, cookie set |
| Valid ticket with PNG | screenshot file appears in `media/ticket_screenshots/` |
| Short description + bad email | 200, form shown again with input kept, error under each field, nothing saved |
| Category `hacking`, severity `extreme` | "Select a valid choice" under both fields |
| `notes.pdf`, fake `.png`, text content type, over 2 MB | error under Screenshot |
| Description with a new line | still ONE line in the file |
| Second visit after success | category is pre-selected |
| Edited cookie value `hacking` | ignored |
| GET `/api/priority/` | 405 |
| POST `/api/priority/` without CSRF token | 403 |
| POST with `X-CSRFToken` | 200 JSON with `priority` |
| Every page | footer shows Request ID, same as `X-Audit-ID` header |

## Viva notes
- **Why POST for the priority check?** It builds a preview on the server. GET must be safe and repeatable, and POST lets Django check the CSRF token.
- **Why a cookie, not a session?** Sessions are not allowed here, and the category is not secret. The server still checks the value because the user can edit cookies.
- **Why redirect after POST?** Refreshing the success page will not submit the ticket again.
- **Why check the file bytes?** The extension and `Content-Type` both come from the browser and can be faked.
- **Why `request` context processor?** So `{{ request.audit_id }}` works in `base.html`.
- No CBV is used.

## Evidence checklist (take screenshots)
1. Valid submit and the success page.
2. Invalid submit with the errors and the kept input.
3. DevTools, Network: `POST /api/priority/` returns 200 JSON and has the `X-CSRFToken` request header.
4. Last line of `data/tickets.jsonl`.
5. DevTools, Application, Cookies: `last_ticket_category`.
6. Footer Request ID and the `X-Audit-ID` response header.
