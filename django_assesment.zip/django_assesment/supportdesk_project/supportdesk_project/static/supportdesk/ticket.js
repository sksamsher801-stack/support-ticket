$(document).ready(function () {
    console.log('We are using JQuery AJAX');

    const form = $('#ticket-form');
    const box = $('#priority-result');
    let timer = null;
// ---------- CSRF ----------
    // Normally we read the token from the hidden input made by {% csrf_token %}.
    // If it is missing, we fall back to the "csrftoken" cookie.
    function getCookie(name) {
        const parts = document.cookie ? document.cookie.split('; ') : [];
        for (const part of parts) {
            const pair = part.split('=');
            if (pair[0] === name) {
                return decodeURIComponent(pair.slice(1).join('='));
            }
        }
        return null;
    }

    function csrfToken() {
        return $('input[name=csrfmiddlewaretoken]').val() || getCookie('csrftoken');
    }
    // ---------- show the result (.text() so no HTML can be injected) ----------
    function show(message, style) {
        box.removeClass('alert-secondary alert-danger alert-warning alert-success alert-info')
           .addClass(style)
           .text(message);
    }
    const styles = {P1: 'alert-danger', P2: 'alert-warning', P3: 'alert-info', P4: 'alert-success'};
// ---------- AJAX POST: severity + description -> priority suggestion ----------
    function checkPriority() {
        const severity = $('#id_severity').val();
        const description = $('#id_description').val();

        if (!severity) {
            show('Select a severity to get a suggestion.', 'alert-secondary');
            return;
        }
        $.ajax({
            url: form.data('priority-url'),               // from {% url 'priority_check' %}
            method: 'POST',
            headers: {'X-CSRFToken': csrfToken()},        // CSRF token for the AJAX POST
            data: {severity: severity, description: description},
            success: function (response) {
                show('Suggested priority: ' + response.priority + ' - ' + response.label +
                     ' (' + response.reasons.join('; ') + ')', styles[response.priority]);
            },
            error: function (error) {
                if (error.status === 403) {
                    show('Security check (CSRF) failed. Please reload the page.', 'alert-danger');
                } else {
                    show(error.responseJSON?.message || 'Could not get a suggestion', 'alert-danger');
                }
            }
        });
    }

    // when severity changes -> check now; while typing -> wait 400 ms, then check
    $('#id_severity').on('change', checkPriority);
    $('#id_description').on('input', function () {
        clearTimeout(timer);
        timer = setTimeout(checkPriority, 400);
    });

    // after a failed submit the form comes back filled, so show the suggestion again
    if ($('#id_severity').val()) {
        checkPriority();
    }
});
