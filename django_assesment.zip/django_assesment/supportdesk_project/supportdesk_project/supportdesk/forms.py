"""
SupportTicketForm - a simple forms.Form (ModelForm needs a database model).

Validation:
  trainee_name -> at least 2 characters, letters / spaces / . ' - only (regex)
  email        -> valid email (EmailField)
  category     -> only the allowed categories
  severity     -> only the allowed severities
  description  -> 20 to 1000 characters
  screenshot   -> optional; .png / .jpg / .jpeg / .gif only, image type, max 2 MB,
                  and the file content must really be an image
"""
import os
import re
from django import forms
from django.conf import settings

CATEGORY_CHOICES = [
    ('', '-- Select a category --'),
    ('bug', 'Bug / Error'),
    ('access', 'Access / Login'),
    ('environment', 'Lab / Environment'),
    ('content', 'Course Content'),
    ('other', 'Other'),
]

SEVERITY_CHOICES = [
    ('', '-- Select severity --'),
    ('low', 'Low'),
    ('medium', 'Medium'),
    ('high', 'High'),
    ('critical', 'Critical'),
]
ALLOWED_CONTENT_TYPES = ['image/png', 'image/jpeg', 'image/gif']
# first bytes of a real image file (so a renamed .exe or .txt is rejected)
IMAGE_SIGNATURES = {
    '.png': [b'\x89PNG\r\n\x1a\n'],
    '.jpg': [b'\xff\xd8\xff'],
    '.jpeg': [b'\xff\xd8\xff'],
    '.gif': [b'GIF87a', b'GIF89a'],
}

def allowed_categories():
    """The real category values (without the empty '-- Select --' choice)."""
    return [value for value, label in CATEGORY_CHOICES if value]

class SupportTicketForm(forms.Form):
    trainee_name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Asha Roy'}),
    )
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'asha@example.com'}),
    )
    category = forms.ChoiceField(
        choices=CATEGORY_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'}),
    )
    severity = forms.ChoiceField(
        choices=SEVERITY_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'}),
    )
    description = forms.CharField(
        max_length=1000,
        help_text='At least 20 characters.',
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 5}),
    )
    screenshot = forms.FileField(
        required=False,
        help_text='Optional. PNG, JPG or GIF, max 2 MB.',
        widget=forms.FileInput(attrs={'class': 'form-control', 'accept': '.png,.jpg,.jpeg,.gif'}),
    )

    def clean_trainee_name(self):
        name = self.cleaned_data['trainee_name'].strip()
        if len(name) < 2:
            raise forms.ValidationError('Name must be at least 2 characters long.')
        # letters, spaces, dot, apostrophe, dash
        if not re.match(r"^[A-Za-z][A-Za-z .'-]*$", name):
            raise forms.ValidationError("Name can contain only letters, spaces and . ' -")
        return name

    def clean_description(self):
        description = self.cleaned_data['description'].strip()
        if len(description) < 20:
            raise forms.ValidationError('Description must be at least 20 characters long.')
        return description

    def clean_screenshot(self):
        screenshot = self.cleaned_data.get('screenshot')
        if not screenshot:
            return None                         # screenshot is optional

        ext = os.path.splitext(screenshot.name)[1].lower()
        if ext not in IMAGE_SIGNATURES:
            raise forms.ValidationError('Only .png, .jpg, .jpeg or .gif files are allowed.')

        if screenshot.content_type not in ALLOWED_CONTENT_TYPES:
            raise forms.ValidationError('The file must be a PNG, JPEG or GIF image.')

        if screenshot.size > settings.MAX_SCREENSHOT_SIZE_MB * 1024 * 1024:
            raise forms.ValidationError(
                f'Screenshot must be {settings.MAX_SCREENSHOT_SIZE_MB} MB or smaller.')

        start = screenshot.read(8)              # check the real content
        screenshot.seek(0)
        if not any(start.startswith(sig) for sig in IMAGE_SIGNATURES[ext]):
            raise forms.ValidationError('The file content does not match its extension.')

        return screenshot
class PriorityCheckForm(forms.Form):
    """Checks the data sent by the AJAX priority checker."""
    severity = forms.ChoiceField(choices=[c for c in SEVERITY_CHOICES if c[0]])
    description = forms.CharField(required=False, max_length=1000)
