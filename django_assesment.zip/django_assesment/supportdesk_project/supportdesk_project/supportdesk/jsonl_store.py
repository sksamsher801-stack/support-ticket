# jsonl_store.py - tickets are saved in data/tickets.jsonl (used instead of a database)
# One ticket = one JSON object on ONE line.
import json
import os
import threading

from django.conf import settings

_lock = threading.Lock()      # only one request writes to the file at a time
# ---------- CREATE ----------
def append(ticket):
    os.makedirs(os.path.dirname(settings.TICKETS_FILE), exist_ok=True)
    # json.dumps escapes new lines inside the text, so the ticket stays on one line
    line = json.dumps(ticket, ensure_ascii=False)
    with _lock:
        with open(settings.TICKETS_FILE, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    return ticket
# ---------- READ ----------
def get_all():
    if not os.path.exists(settings.TICKETS_FILE):
        return []
    tickets = []
    with open(settings.TICKETS_FILE, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                tickets.append(json.loads(line))
            except json.JSONDecodeError:
                continue                      # skip a damaged line
    return tickets
def get_one(ticket_id):
    for ticket in get_all():
        if ticket['ticket_id'] == ticket_id:
            return ticket
    return None
