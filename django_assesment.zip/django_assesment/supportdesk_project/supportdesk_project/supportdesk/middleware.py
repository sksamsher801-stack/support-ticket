import uuid
class AuditIdMiddleware:
    """Adds request.audit_id to EVERY request (used in the template footer)."""

    def __init__(self, get_response):
        # runs only ONCE, when the server starts
        self.get_response = get_response
    def __call__(self, request):
        # runs for EVERY request
        # 1. BEFORE the view: make a new id (never trust an id sent by the browser)
        request.audit_id = uuid.uuid4().hex[:12]
        print("Request :", request.audit_id, request.method, request.path)
        # 2. go to the view
        response = self.get_response(request)
        # 3. AFTER the view: send the same id back in a header, easy to see in DevTools
        response['X-Audit-ID'] = request.audit_id
        print("Response:", request.audit_id, response.status_code)

        return response
