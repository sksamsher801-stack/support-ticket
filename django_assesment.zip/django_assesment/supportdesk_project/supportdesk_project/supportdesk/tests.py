# Run with:  python manage.py test supportdesk
# Uses a temporary tickets.jsonl + temporary media folder, so real data is not touched.
import json
import os
import tempfile
from pathlib import Path

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, SimpleTestCase, override_settings
from django.urls import reverse

PNG_BYTES = b'\x89PNG\r\n\x1a\n' + b'0' * 64


def png(name='shot.png'):
    return SimpleUploadedFile(name, PNG_BYTES, content_type='image/png')


class TicketTests(SimpleTestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.override = override_settings(TICKETS_FILE=base / 'tickets.jsonl',
                                          MEDIA_ROOT=base / 'media')
        self.override.enable()
        self.base = base
        self.jsonl = base / 'tickets.jsonl'
        self.media = base / 'media'

    def tearDown(self):
        self.override.disable()
        self.tmp.cleanup()

    def submit(self, **changes):
        data = {'trainee_name': 'Asha Roy', 'email': 'asha@example.com', 'category': 'access',
                'severity': 'high', 'description': 'I cannot login to the lab portal since morning.'}
        data.update(changes)
        return self.client.post(reverse('ticket_form'), data)

    # ---------- page + middleware ----------
    def test_page_shows_form_and_footer_audit_id(self):
        r = self.client.get(reverse('ticket_form'))
        self.assertContains(r, 'id="ticket-form"')
        self.assertContains(r, 'Request ID:')
        self.assertContains(r, r['X-Audit-ID'])          # same id in footer and header
        self.assertEqual(len(r['X-Audit-ID']), 12)

    def test_each_request_gets_a_new_audit_id(self):
        a = self.client.get(reverse('ticket_form'))['X-Audit-ID']
        b = self.client.get(reverse('ticket_form'))['X-Audit-ID']
        self.assertNotEqual(a, b)

    # ---------- valid submit ----------
    def test_valid_submit_saves_one_json_line_and_redirects(self):
        r = self.submit()
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r['Location'].startswith('/tickets/success/'))

        lines = self.jsonl.read_text(encoding='utf-8').splitlines()
        self.assertEqual(len(lines), 1)
        ticket = json.loads(lines[0])
        self.assertEqual(ticket['email'], 'asha@example.com')
        self.assertEqual(ticket['category'], 'access')
        self.assertIsNone(ticket['screenshot'])
        self.assertEqual(len(ticket['audit_id']), 12)

        page = self.client.get(r['Location'])             # success page reads the saved ticket
        self.assertContains(page, 'Asha Roy')

    def test_multiline_description_stays_on_one_line(self):
        self.submit(description='Line one of the problem.\nLine two of the problem.')
        self.assertEqual(len(self.jsonl.read_text(encoding='utf-8').splitlines()), 1)

    def test_success_page_unknown_ticket_is_404(self):
        r = self.client.get(reverse('ticket_success', args=['11111111-1111-1111-1111-111111111111']))
        self.assertEqual(r.status_code, 404)

    # ---------- invalid submit ----------
    def test_invalid_submit_keeps_input_and_shows_errors(self):
        r = self.submit(description='too short', email='not-an-email')
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, 'Asha Roy')                # name kept
        self.assertContains(r, 'too short')               # description kept
        self.assertContains(r, 'Enter a valid email address')
        self.assertContains(r, 'at least 20 characters')
        self.assertFalse(self.jsonl.exists())             # nothing saved

    def test_bad_category_and_severity(self):
        r = self.submit(category='hacking', severity='extreme')
        self.assertContains(r, 'Select a valid choice', count=2)

    def test_empty_form_shows_required_errors(self):
        r = self.client.post(reverse('ticket_form'), {})
        self.assertContains(r, 'This field is required.', count=5)   # screenshot is optional

    # ---------- screenshot ----------
    def test_screenshot_bad_extension(self):
        f = SimpleUploadedFile('notes.pdf', b'%PDF-1.4', content_type='application/pdf')
        r = self.submit(screenshot=f)
        self.assertContains(r, 'Only .png, .jpg, .jpeg or .gif files are allowed.')
        self.assertFalse(self.jsonl.exists())

    def test_screenshot_wrong_content_type(self):
        f = SimpleUploadedFile('shot.png', PNG_BYTES, content_type='text/plain')
        r = self.submit(screenshot=f)
        self.assertContains(r, 'must be a PNG, JPEG or GIF image')

    def test_screenshot_fake_image(self):
        f = SimpleUploadedFile('fake.png', b'this is not an image', content_type='image/png')
        r = self.submit(screenshot=f)
        self.assertContains(r, 'does not match its extension')

    def test_screenshot_too_big(self):
        f = SimpleUploadedFile('big.png', PNG_BYTES + b'0' * (2 * 1024 * 1024),
                               content_type='image/png')
        r = self.submit(screenshot=f)
        self.assertContains(r, '2 MB or smaller')

    def test_valid_screenshot_saved_in_media(self):
        r = self.submit(screenshot=png())
        self.assertEqual(r.status_code, 302)
        ticket = json.loads(self.jsonl.read_text(encoding='utf-8').splitlines()[0])
        self.assertTrue(ticket['screenshot'].startswith('ticket_screenshots/'))
        self.assertEqual(len(os.listdir(self.media / 'ticket_screenshots')), 1)

    # ---------- cookie ----------
    def test_cookie_is_set_after_success(self):
        r = self.submit(category='bug')
        self.assertEqual(r.cookies['last_ticket_category'].value, 'bug')

    def test_cookie_not_set_after_failure(self):
        r = self.submit(description='short')
        self.assertNotIn('last_ticket_category', r.cookies)

    def test_cookie_preselects_category(self):
        self.submit(category='environment')
        r = self.client.get(reverse('ticket_form'))
        self.assertContains(r, 'value="environment" selected')

    def test_edited_cookie_is_ignored(self):
        self.client.cookies['last_ticket_category'] = 'hacking'
        r = self.client.get(reverse('ticket_form'))
        self.assertNotContains(r, 'value="hacking"')

    # ---------- AJAX priority checker ----------
    def test_priority_get_not_allowed(self):
        self.assertEqual(self.client.get(reverse('priority_check')).status_code, 405)

    def test_priority_post_without_csrf_token_is_403(self):
        client = Client(enforce_csrf_checks=True)         # the normal test client skips CSRF
        r = client.post(reverse('priority_check'), {'severity': 'high', 'description': 'x'})
        self.assertEqual(r.status_code, 403)

    def test_priority_post_with_csrf_token(self):
        client = Client(enforce_csrf_checks=True)
        client.get(reverse('ticket_form'))                # {% csrf_token %} sets the cookie
        token = client.cookies['csrftoken'].value
        r = client.post(reverse('priority_check'),
                        {'severity': 'high', 'description': 'production is down'},
                        HTTP_X_CSRFTOKEN=token)           # same as the X-CSRFToken header
        self.assertEqual(r.status_code, 200, r.content)
        self.assertEqual(r.json()['priority'], 'P1')

    def test_priority_minor_keyword_lowers_priority(self):
        r = self.client.post(reverse('priority_check'),
                             {'severity': 'medium', 'description': 'a small typo on page 3'})
        self.assertEqual(r.json()['priority'], 'P4')

    def test_priority_invalid_severity(self):
        r = self.client.post(reverse('priority_check'), {'severity': 'banana', 'description': ''})
        self.assertEqual(r.status_code, 400)
        self.assertIn('severity', r.json()['errors'])
