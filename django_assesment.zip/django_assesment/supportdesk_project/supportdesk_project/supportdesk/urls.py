from django.urls import path

from . import views

urlpatterns = [
    path('', views.ticket_create, name='ticket_form'),
    path('tickets/success/<uuid:ticket_id>/', views.ticket_success, name='ticket_success'),
    path('api/priority/', views.priority_check, name='priority_check'),
]
