import os
import uuid
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.http import Http404, HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views.decorators.http import require_GET, require_http_methods, require_POST
from . import jsonl_store
from .forms import PriorityCheckForm, SupportTicketForm, allowed_categories

SCREENSHOT_SUBDIR = 'ticket_screenshots'
COOKIE_NAME = 'last_ticket_category'
COOKIE_MAX_AGE = 60 * 60 * 24 * 30          # 30 days
# ---------------- helpers ----------------
def save_screenshot(uploaded):
    """Save the screenshot in media/ticket_screenshots/ with a random name; return the path for the JSONL."""
    ext = os.path.splitext(uploaded.name)[1].lower()
    storage = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, SCREENSHOT_SUBDIR))
    saved_name = storage.save(f"{uuid.uuid4().hex}{ext}", uploaded)
    return f"{SCREENSHOT_SUBDIR}/{saved_name}"
def delete_screenshot(relative_path):
    """Remove a screenshot file if it exists."""
    if relative_path:
        full = os.path.join(settings.MEDIA_ROOT, relative_path)
        if os.path.isfile(full):
            os.remove(full)
# ---------------- TICKET FORM (GET shows it, POST saves it) ----------------
@require_http_methods(['GET', 'POST'])
def ticket_create(request: HttpRequest) -> HttpResponse:
    if request.method == 'POST':
        # The form is bound to request.POST, so when validation fails the SAME form is
        # shown again with everything the user typed (this fixes the "lost input" bug).
        form = SupportTicketForm(request.POST, request.FILES)
        if form.is_valid():
            data = form.cleaned_data
            ticket_id = uuid.uuid4()
            screenshot_path = None
            if data['screenshot']:
                screenshot_path = save_screenshot(data['screenshot'])
            ticket = {
                'ticket_id': str(ticket_id),
                'created_at': timezone.now().isoformat(),
                'audit_id': request.audit_id,             # set by AuditIdMiddleware
                'trainee_name': data['trainee_name'],
                'email': data['email'],
                'category': data['category'],
                'severity': data['severity'],
                'description': data['description'],
                'screenshot': screenshot_path,
            }
            try:
                jsonl_store.append(ticket)
            except OSError:
                delete_screenshot(screenshot_path)            # no orphan file
                raise

            # Post -> Redirect -> Get using the URL NAME (refresh will not save it twice)
            response = redirect('ticket_success', ticket_id=ticket_id)

            # remember the category in a COOKIE (sessions are not allowed)
            response.set_cookie(COOKIE_NAME, data['category'],
                                max_age=COOKIE_MAX_AGE, samesite='Lax')
            return response
    else:
        # First visit: pre-select the category from the cookie
        initial = {}
        remembered = request.COOKIES.get(COOKIE_NAME)
        if remembered in allowed_categories():                # a cookie can be edited by the user
            initial['category'] = remembered
        form = SupportTicketForm(initial=initial)

    return render(request, 'supportdesk/ticket_form.html', {'form': form})
# ---------------- SUCCESS PAGE ----------------
@require_GET
def ticket_success(request: HttpRequest, ticket_id) -> HttpResponse:
    ticket = jsonl_store.get_one(str(ticket_id))
    if ticket is None:
        raise Http404('Ticket not found')
    return render(request, 'supportdesk/ticket_success.html', {'ticket': ticket})
# ---------------- AJAX PRIORITY CHECKER ----------------
# POST, not GET: it creates a preview, so it must not be a "safe" GET request.
# No @csrf_exempt: Django checks the CSRF token that ticket.js sends.
SCORES = {'low': 1, 'medium': 2, 'high': 3, 'critical': 4}
PRIORITIES = {4: ('P1', 'Urgent'), 3: ('P2', 'High'), 2: ('P3', 'Normal'), 1: ('P4', 'Low')}
RAISE_WORDS = ['data loss', 'cannot login', "can't login", 'crash', 'down', 'production',
               'security', 'deadline', 'exam', 'blocked']
LOWER_WORDS = ['typo', 'cosmetic', 'suggestion', 'minor', 'whenever']
@require_POST
def priority_check(request: HttpRequest) -> JsonResponse:
    form = PriorityCheckForm(request.POST)
    if not form.is_valid():
        errors = {field: [str(e) for e in errs] for field, errs in form.errors.items()}
        return JsonResponse({'ok': False, 'message': 'Please correct the errors',
                             'errors': errors}, status=400)
    severity = form.cleaned_data['severity']
    text = form.cleaned_data['description'].lower()
    score = SCORES[severity]
    reasons = [f"severity is {severity}"]
    if any(word in text for word in RAISE_WORDS):
        score += 1
        reasons.append('description has a serious keyword')
    if any(word in text for word in LOWER_WORDS):
        score -= 1
        reasons.append('description has a minor keyword')
    score = max(1, min(4, score))
    code, label = PRIORITIES[score]
    return JsonResponse({'ok': True, 'priority': code, 'label': label,
                         'reasons': reasons, 'audit_id': request.audit_id})
