import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-supportdesk-dev-key-change-me'
DEBUG = True
ALLOWED_HOSTS = ['127.0.0.1', 'localhost']


# ---------------------------------------------------------------
# Apps: admin, auth, contenttypes, sessions and messages are REMOVED
# (they need database tables / sessions are not allowed in this task).
# Only staticfiles + supportdesk.
# ---------------------------------------------------------------
INSTALLED_APPS = [
    'django.contrib.staticfiles',
    'supportdesk.apps.SupportdeskConfig',
]

# ---------------------------------------------------------------
# Middleware: session/auth/messages removed.
# CSRF stays ON - it uses a cookie, not the database.
# AuditIdMiddleware (my custom middleware) adds request.audit_id.
# ---------------------------------------------------------------
MIDDLEWARE = [
    'supportdesk.middleware.AuditIdMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'supportdesk_project.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',  # {{ request.audit_id }} in templates
                'django.template.context_processors.media',    # {{ MEDIA_URL }} in templates
            ],
        },
    },
]

WSGI_APPLICATION = 'supportdesk_project.wsgi.application'

# ---------------------------------------------------------------
# NO DATABASE. Tickets are stored as JSON lines in a file instead.
# ---------------------------------------------------------------
DATABASES = {}

TICKETS_FILE = BASE_DIR / 'data' / 'tickets.jsonl'

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

# Uploaded screenshots are saved here: media/ticket_screenshots/<random>.png
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Upload limit used by SupportTicketForm
MAX_SCREENSHOT_SIZE_MB = 2
