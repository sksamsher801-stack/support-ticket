from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path

# admin/ removed - Django admin needs a database.
urlpatterns = [
    path('', include('supportdesk.urls')),
]

# Serve uploaded screenshots (media/) during development (DEBUG=True only).
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
